<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/styles2.css" />

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>

    <title>BerpusCell</title>
</head>


<body class="text-center">
    <ul class="nav justify-content-center menucolor">
        <li class="nav-item">
            <a class="nav-link menucolor" href="<?= base_url(); ?>/">HOME</a>
        </li>
        <li class="nav-item">
            <a class="nav-link menucolor-active" href="<?= base_url(); ?>/track">TRACK</a>
        </li>
        <li class="nav-item">
            <a class="nav-link menucolor" href="<?= base_url(); ?>/booking">BOOKING</a>
        </li>
        <li class="nav-item">
            <a class="nav-link menucolor" href="<?= base_url(); ?>/about">ABOUT US</a>
        </li>
    </ul>
    <div class="container mt-5 py-5">
        <div class="col md-6">
            <div class="row">
                <h1>TRACK YOUR SERVICE STATUS</h1>
            </div>
        </div>
        <div class="col mt-5 py-5 track">
            <div class="row ">
                <form action="" method="post">
                    <input id="" class="form-control" type="text" value="" required="" name="invoice" placeholder="INPUT YOUR INVOICE HERE">
                </form>
            </div>
        </div>
    </div>
    <div class="container px-1 px-md-4 py-5 mx-auto">
        <div class="card">
            <div class="row d-flex justify-content-between px-3 top">
                <div class="d-flex">
                    <h5>ORDER <span class="text-primary font-weight-bold">#Y34XDHR</span></h5>
                </div>
                <div class="d-flex flex-column text-sm-right">
                    <p class="mb-0">Expected Arrival <span>01/12/19</span></p>
                    <p>USPS <span class="font-weight-bold">234094567242423422898</span></p>
                </div>
            </div> <!-- Add class 'active' to progress -->
            <div class="row d-flex justify-content-center">
                <div class="col-12">
                    <ul id="progressbar" class="text-center">
                        <li class="active step0"></li>
                        <li class="active step0"></li>
                        <li class="active step0"></li>
                        <li class="step0"></li>
                    </ul>
                </div>
            </div>
            <div class="row justify-content-between top">
                <div class="row d-flex icon-content"> <img class="icon" src="https://i.imgur.com/9nnc9Et.png">
                    <div class="d-flex flex-column">
                        <p class="font-weight-bold">Order<br>Processed</p>
                    </div>
                </div>
                <div class="row d-flex icon-content"> <img class="icon" src="https://i.imgur.com/u1AzR7w.png">
                    <div class="d-flex flex-column">
                        <p class="font-weight-bold">Order<br>Shipped</p>
                    </div>
                </div>
                <div class="row d-flex icon-content"> <img class="icon" src="https://i.imgur.com/TkPm63y.png">
                    <div class="d-flex flex-column">
                        <p class="font-weight-bold">Order<br>En Route</p>
                    </div>
                </div>
                <div class="row d-flex icon-content"> <img class="icon" src="https://i.imgur.com/HdsziHP.png">
                    <div class="d-flex flex-column">
                        <p class="font-weight-bold">Order<br>Arrived</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>